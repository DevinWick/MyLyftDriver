package com.phantomarts.mylyftdriver;

import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.google.firebase.auth.FirebaseAuth;
import com.phantomarts.mylyftdriver.Util.RequestHandler;

import org.json.JSONObject;

public class CompleteRegStage1Fragment extends Fragment implements View.OnClickListener {
    private EditText etPhoneno;
    private Button btnDone;
    private ProgressDialog progressDialog;

    private FirebaseAuth firebaseAuth;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View inflate=inflater.inflate(R.layout.fragment_compreg_stage1,container,false);

        firebaseAuth=FirebaseAuth.getInstance();

        progressDialog=new ProgressDialog(getContext());

        etPhoneno=inflate.findViewById(R.id.etPhoneno);
        btnDone=inflate.findViewById(R.id.btnDone);

        btnDone.setOnClickListener(this);
        etPhoneno.addTextChangedListener(new TextWatcher() {
            CharSequence beforeTextChanged;
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                beforeTextChanged=s.toString();

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                System.out.println(s+"\n"+start+"\n"+before+"\n"+count);
                if(s.length()<=10){
                    if(s.length()!=0){
                        if(s.charAt(0)=='0'){
                            if(s.length()==1){
                                etPhoneno.setText("");
                                return;
                            }
                            etPhoneno.setText(s.subSequence(1,count));
                        }else if(s.length()>9){
                            etPhoneno.setText(beforeTextChanged);
                            return;
                        }
                    }
                }else{
                    etPhoneno.setText("");
                }
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });

        return inflate;
    }

    @Override
    public void onClick(View v) {
        if(v==btnDone){
            //validate phone no
            if(!validatePhoneNo()){
                etPhoneno.setError("Invalid Phone No");
                etPhoneno.requestFocus();
                return;
            }

            progressDialog.setMessage("Validating Phone No");
            progressDialog.show();
            new RequestAsync().execute();
            return;
        }
    }

    private boolean validatePhoneNo() {
        String phoneNo=etPhoneno.getText().toString();
        try {
            Double.parseDouble(phoneNo);
            if(phoneNo.length()>9){
                return false;
            }
            return true;
        }catch(NumberFormatException ex){
            return false;
        }
    }

    public class RequestAsync extends AsyncTask<String,String,String> {
        @Override
        protected String doInBackground(String... strings) {
            try {
                // POST Request
                JSONObject postDataParams = new JSONObject();
                System.out.println(firebaseAuth.getCurrentUser());
                postDataParams.put("uid", firebaseAuth.getCurrentUser().getUid());
                postDataParams.put("phoneno", "+940"+etPhoneno.getText().toString());
                postDataParams.put("reqtype", "0");

                return RequestHandler.sendPost("http://192.168.43.27:8080/LyftMeServer/VerifyPhone",postDataParams);
            }
            catch(Exception e){
                e.printStackTrace();
                return new String("Exception: " + e.getMessage());

            }
        }

        @Override
        protected void onPostExecute(String s) {
            if(s!=null){
                if(s.equals("1")){
                    progressDialog.dismiss();
                    CompleteRegStage2Fragment stage2Fragment=new CompleteRegStage2Fragment();
                    getActivity().getSupportFragmentManager()
                            .beginTransaction()
                            .replace(R.id.parentLayoutCompReg, stage2Fragment,"compreg_stage2")
                            .setCustomAnimations(android.R.anim.fade_in, android.R.anim.fade_out)
                            .addToBackStack(null)
                            .commit();
                }else{
                    Toast.makeText(getActivity(), "Validation Failed", Toast.LENGTH_LONG).show();
                }

            }

        }


    }

}
